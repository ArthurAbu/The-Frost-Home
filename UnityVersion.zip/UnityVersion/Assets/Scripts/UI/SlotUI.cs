using UnityEngine;
using UnityEngine.UI;

public class SlotUI : MonoBehaviour
{
    [SerializeField] private Image icon;
    [SerializeField] private Text countText;
    [SerializeField] private Image background;

    private ItemData item;
    private int count;

    // Устанавливаем предмет в ячейку
    public void SetItem(ItemData newItem, int newCount)
    {
        item = newItem;
        count = newCount;

        bool hasItem = item != null;

        // Управляем видимостью
        if (icon != null) icon.enabled = hasItem;
        if (countText != null) countText.text = hasItem && count > 1 ? count.ToString() : "";
        if (background != null)
        {
            // Прозрачный фон при пустом слоте, непрозрачный — при предмете
            background.color = hasItem 
                ? new Color(1f, 1f, 1f, 0.8f)  // полупрозрачный фон
                : new Color(0f, 0f, 0f, 0f);   // полностью прозрачный
        }

        // Устанавливаем спрайт, если есть
        if (hasItem && icon != null && item.icon != null)
        {
            icon.sprite = item.icon;
        }
        else if (icon != null)
        {
            icon.sprite = null;
        }
    }

    public ItemData GetItem() => item;
    public int GetCount() => count;
}