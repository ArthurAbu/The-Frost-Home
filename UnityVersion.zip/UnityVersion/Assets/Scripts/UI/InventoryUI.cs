using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class InventoryUI : MonoBehaviour
{
    [SerializeField] private InventorySystem inventory;
    [SerializeField] private GameObject inventoryPanel;
    [SerializeField] private Transform hotbarGrid;
    [SerializeField] private Transform mainGrid;

    [SerializeField] private GameObject slotPrefab;
    [SerializeField] private GameObject hotbarSlotPrefab;

    private List<SlotUI> hotbarSlots = new();
    private List<SlotUI> mainSlots = new();

    void Start()
    {
        CreateHotbar();
        CreateMainInventory();
        RefreshUI();
        inventoryPanel.SetActive(false);
        inventory.DebugCheckInventory();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.I))
            inventoryPanel.SetActive(!inventoryPanel.activeSelf);
    }

    // Слоты хотбара
    void CreateHotbar()
    {
        hotbarSlots.Clear();
        for (int i = 0; i < 10; i++)
        {
            var go = Instantiate(hotbarSlotPrefab, hotbarGrid);
            var slot = go.GetComponent<SlotUI>();
            hotbarSlots.Add(slot);
        }
    }

    // Слоты основного инвентаря
    void CreateMainInventory()
    {
        mainSlots.Clear();
        for (int i = 0; i < 80; i++)
        {
            var go = Instantiate(slotPrefab, mainGrid);
            var slot = go.GetComponent<SlotUI>();
            mainSlots.Add(slot);
        }
    }

    // Обновляет отображение инвентаря
    public void RefreshUI()
    {
        // Хотбар
        for (int i = 0; i < 10; i++)
        {
            if (i < inventory.slots.Count)
                hotbarSlots[i].SetItem(inventory.slots[i].item, inventory.slots[i].count);
            else
                hotbarSlots[i].SetItem(null, 0);
        }

        // Основной инвентарь
        for (int i = 0; i < inventory.slots.Count && i < mainSlots.Count; i++)
            mainSlots[i].SetItem(inventory.slots[i].item, inventory.slots[i].count);
    }
}