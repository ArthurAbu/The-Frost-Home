using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class InventorySlot
{
    public ItemData item;
    public int count;
}

public class InventorySystem : MonoBehaviour
{
    [SerializeField] private int slotCount = 90; // 80 инвентаря + 10 для хотбар
    public List<InventorySlot> slots = new();

    void Awake()
    {
        slots.Clear();
        for (int i = 0; i < slotCount; i++)
            slots.Add(new InventorySlot { item = null, count = 0 });

        // 🔥 Тестовые предметы
        var wood = Resources.Load<ItemData>("Items/Wood");
        var stone = Resources.Load<ItemData>("Items/Stone");
        var axe = Resources.Load<ItemData>("Items/Axe");

        // Тестовые предметы
        if (wood && stone && axe)
        {
            AddItem(wood, 20);
            AddItem(stone, 10);
            AddItem(axe, 1);
        }
    }
    // Добавляет предмет в инвентарь
    public bool AddItem(ItemData item, int count)
    {
        if (item == null) return false;

        // Добавляет в существующие стаки
        foreach (var slot in slots)
        {
            if (slot.item == item && slot.count < item.stackLimit)
            {
                int add = Mathf.Min(count, item.stackLimit - slot.count);
                slot.count += add;
                count -= add;
                if (count <= 0) return true;
            }
        }

        // Потом — в пустые слоты
        foreach (var slot in slots)
        {
            if (slot.item == null)
            {
                int add = Mathf.Min(count, item.stackLimit);
                slot.item = item;
                slot.count = add;
                count -= add;
                if (count <= 0) return true;
            }
        }

        return count == 0;
    }

    // Удаляет предмет из инвентаря
    public bool RemoveItem(ItemData item, int count)
    {
        int removed = 0;
        foreach (var slot in slots)
        {
            if (slot.item == item)
            {
                int take = Mathf.Min(slot.count, count - removed);
                slot.count -= take;
                removed += take;
                if (slot.count <= 0) slot.item = null;
                if (removed >= count) return true;
            }
        }
        return false;
    }

    // Возвращает общее количество предметов в инвентаре
    public int GetItemCount(ItemData item)
    {
        int total = 0;
        foreach (var slot in slots)
            if (slot.item == item) total += slot.count;
        return total;
    }

    // проверка инвентаря
    public void DebugCheckInventory()
    {
        Debug.Log("Проверка инвкнтаря:");
        Debug.Log($"Всего слотов: {slots.Count}");

        int itemCount = 0;
        for (int i = 0; i < slots.Count; i++)
        {
            var s = slots[i];
            if (s.item != null)
            {
                Debug.Log($"Слот {i,2}: {s.item.itemName,-10} x{s.count}");
                itemCount++;
            }
        }

        Debug.Log($"Найдено предметов: {itemCount}/{slots.Count}");
    }
}