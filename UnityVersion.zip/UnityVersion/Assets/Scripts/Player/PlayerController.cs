using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class PlayerController : MonoBehaviour
{
    [Header("Movement Settings")]  // переменные для движений
    public float walkSpeed = 5f;
    public float runSpeed = 8f;
    public float jumpSpeed = 7f;
    public float gravity = -9.81f;

    [Header("Ground Check")]   // переменные для проверки земли под игроком
    public float groundDistance = 0.1f;
    public LayerMask groundMask;

    [Header("Jump Cooldown")]  // переменные время между прыжками
    public float jumpCooldownDuration = 0.3f; // Время между прыжками

    private CharacterController controller;
    private Vector3 velocity;
    private bool isGrounded;
    private float lastJumpTime = -999f; // Чтобы первый прыжок был возможен

    void Start()
    {
        controller = GetComponent<CharacterController>();
        Cursor.lockState = CursorLockMode.Locked;
    }

    void Update()
    {
        CheckGrounded();
        HandleMovement();
        ApplyGravity();
    }

    //проверяет стоит ли персонаж на земле
    private void CheckGrounded()
    {
        Vector3 center = transform.position;
        center.y -= controller.height / 2f;
        center.y -= controller.center.y;

        float checkRadius = 0.2f;
        Collider[] hitColliders = Physics.OverlapSphere(center, checkRadius, groundMask, QueryTriggerInteraction.Ignore);

        isGrounded = false;
        foreach (var col in hitColliders)
        {
            // проверяем что коллизия ниже центра, чтобы не ловить стены
            if (col.transform.position.y < center.y + 0.05f)
            {
                isGrounded = true;
                break;
            }
        }
    }

    //обработка движения персонажа
    private void HandleMovement()
    {
        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");

        Vector3 move = transform.right * x + transform.forward * z;

        float currentSpeed = Input.GetKey(KeyCode.LeftShift) ? runSpeed : walkSpeed;

        controller.Move(move * currentSpeed * Time.deltaTime);

        // Прыжок только если на земле
        if (isGrounded && Input.GetButtonDown("Jump") && CanJump())
        {
            velocity.y = jumpSpeed;
            lastJumpTime = Time.time;
        }
    }

    // задержка между прыжками
    private bool CanJump()
    {
        return Time.time - lastJumpTime >= jumpCooldownDuration;
    }

    //гравитация
    private void ApplyGravity()
    {
        velocity.y += gravity * Time.deltaTime;

        if (isGrounded && velocity.y < 0)
        {
            velocity.y = -2f;
        }

        controller.Move(velocity * Time.deltaTime);
    }
}