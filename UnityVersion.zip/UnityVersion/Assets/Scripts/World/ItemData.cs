using UnityEngine;

[CreateAssetMenu(fileName = "NewItem", menuName = "Inventory/Item Data", order = 1)]
public class ItemData : ScriptableObject
{
    public string itemName;     // Имя предмета
    public Sprite icon;         // Иконка
    public int stackLimit = 1;  // Сколько можно положить в одну ячейку
    public ItemType type;       // Тип предмета
    public int weight = 1;      // Вес предмета
}

// Типы предметов
public enum ItemType
{
    Resource,    //ресурс
    Tool,        //Инструмнт
    Food,        //Еда
    Weapon,      //оружие
    CraftedItem  //созданный предмет
}